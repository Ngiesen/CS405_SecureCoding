#include "pch.h"
#include "gtest/gtest.h"
#include <vector>
#include <memory>
#include <cstdlib>
#include <ctime>
#include <cassert>

// Global test environment (no change needed)
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    void SetUp() override
    {
        srand(static_cast<unsigned int>(time(nullptr)));
    }

    void TearDown() override {}
};

// Shared test class for vector testing
class CollectionTest : public ::testing::Test
{
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        collection->clear();
        collection.reset(nullptr);
    }

    void add_entries(int count)
    {
        assert(count > 0);
        for (int i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// Test that collection smart pointer is created
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Test that collection is empty on creation
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Disabled fail test (optional)
// TEST_F(CollectionTest, AlwaysFail)
// {
//     FAIL();
// }

// Add single value
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 1);
}

// Add five values
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);
    EXPECT_EQ(collection->size(), 5);
}

// Max size vs size
TEST_F(CollectionTest, MaxSizeIsGreaterOrEqualToSize)
{
    std::vector<int> sizes = { 0, 1, 5, 10 };
    for (int size : sizes)
    {
        collection->clear();
        add_entries(size);
        EXPECT_GE(collection->max_size(), collection->size());
    }
}

// Capacity vs size
TEST_F(CollectionTest, CapacityIsGreaterOrEqualToSize)
{
    std::vector<int> sizes = { 0, 1, 5, 10 };
    for (int size : sizes)
    {
        collection->clear();
        add_entries(size);
        EXPECT_GE(collection->capacity(), collection->size());
    }
}

// Resize increases collection
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
    collection->resize(5);
    EXPECT_EQ(collection->size(), 5);
}

// Resize decreases collection
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
    add_entries(10);
    collection->resize(5);
    EXPECT_EQ(collection->size(), 5);
}

// Resize to zero
TEST_F(CollectionTest, ResizeToZero)
{
    add_entries(5);
    collection->resize(0);
    EXPECT_TRUE(collection->empty());
}

// Clear the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    add_entries(10);
    collection->clear();
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}

// Erase(begin, end)
TEST_F(CollectionTest, EraseBeginToEndClearsCollection)
{
    add_entries(10);
    collection->erase(collection->begin(), collection->end());
    EXPECT_TRUE(collection->empty());
}

// Reserve increases capacity but not size
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    collection->reserve(100);
    EXPECT_GE(collection->capacity(), 100);
    EXPECT_EQ(collection->size(), 0);
}

// Negative: at() throws std::out_of_range
TEST_F(CollectionTest, AtThrowsOutOfRange)
{
    EXPECT_THROW(collection->at(1), std::out_of_range);
}

// Negative: accessing after reset (crashes = dead test)
TEST_F(CollectionTest, AccessAfterResetThrows)
{
    collection.reset(nullptr);
    ASSERT_EQ(collection, nullptr);
    EXPECT_DEATH(collection->push_back(1), "");
}

// Custom Positive: values persist after resize up
TEST_F(CollectionTest, ValuesRemainAfterResizeUp)
{
    add_entries(3);
    int first = collection->at(0);
    collection->resize(6);
    EXPECT_EQ(collection->at(0), first);
    EXPECT_EQ(collection->size(), 6);
}
