// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>  // for std::numeric_limits

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // account_number must stay before user_input and unchanged
    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    std::cout << "Enter a value: ";

    // Use getline to limit input size safely and prevent overflow
    std::cin.getline(user_input, sizeof(user_input));

    // Check if input was too long and notify user
    if (std::cin.fail()) {
        std::cin.clear(); // clear error flags
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // discard remaining input
        std::cout << "Incorrect Account Number (Length)! Please enter less than 20 characters." << std::endl;
        return 1; // exit or re-prompt as you like
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}
