#include <iostream>
#include <limits>
#include <optional>
#include <typeinfo>

// Add numbers function
template <typename T>
std::optional<T> add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;
    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Overflow check: if result + increment would exceed max
        if (std::numeric_limits<T>::max() - result < increment)
        {
            return std::nullopt;
        }
        result += increment;
    }
    return result;
}

// Subtract numbers
template <typename T>
std::optional<T> subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;
    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Underflow check: if result - decrement would go below 0
        if (result < decrement)
        {
            return std::nullopt;
        }
        result -= decrement;
    }
    return result;
}

// Test overflow
template <typename T>
void test_overflow()
{
    const unsigned long int steps = 5;
    const T increment = std::numeric_limits<T>::max() / steps;
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    auto result = add_numbers<T>(start, increment, steps);
    if (result.has_value()) {
        std::cout << +result.value() << " [Overflow: false]" << std::endl;
    }
    else {
        std::cout << "[Overflow detected]" << std::endl;
    }

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1);
    if (result.has_value()) {
        std::cout << +result.value() << " [Overflow: false]" << std::endl;
    }
    else {
        std::cout << "[Overflow detected]" << std::endl;
    }
}

// Test underflow
template <typename T>
void test_underflow()
{
    const unsigned long int steps = 5;
    const T decrement = std::numeric_limits<T>::max() / steps;
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;

    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    auto result = subtract_numbers<T>(start, decrement, steps);
    if (result.has_value()) {
        std::cout << +result.value() << " [Underflow: false]" << std::endl;
    }
    else {
        std::cout << "[Underflow detected]" << std::endl;
    }

    std::cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1);
    if (result.has_value()) {
        std::cout << +result.value() << " [Underflow: false]" << std::endl;
    }
    else {
        std::cout << "[Underflow detected]" << std::endl;
    }
}

// Do all overflow tests
void do_overflow_tests(const std::string& star_line)
{
    std::cout << "\n" << star_line << "\n*** Running Overflow Tests ***\n" << star_line << std::endl;

    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

// Do all underflow tests
void do_underflow_tests(const std::string& star_line)
{
    std::cout << "\n" << star_line << "\n*** Running Underflow Tests ***\n" << star_line << std::endl;

    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

// Main Function
int main()
{
    const std::string star_line = std::string(50, '*');
    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    do_overflow_tests(star_line);
    do_underflow_tests(star_line);

    std::cout << "\nAll Numeric Underflow / Overflow Tests Complete!" << std::endl;
    return 0;
}
